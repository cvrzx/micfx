# iOS signing checklist

To share `group.f172ad8c5e5f97bc.1`, **both apps** need valid signatures under profiles that authorize this App Group. Bundle identifiers must be allowed by their respective profiles. The profile from the uploaded Endcord IPA lists this App Group, but its app identifier is not suitable evidence that it can sign the new controller bundle.

- Discord IPA after injection: `com.hammerandchisel.discord` or your signing tool's re-bundled identifier; verify the profile matches it. Configure `DiscordMicFX.entitlements` at signing time, not as a loose file in the IPA.
- Qt controller: `com.micfx.apo.control` as the example bundle ID; provision an app identifier and App Groups entitlement explicitly for the signing Team. Configure `APOController.entitlements` at signing time.
- Do not copy a signing certificate/private key into this project ZIP. The app-group name is not a bypass of iOS entitlement checking.
- Sign frameworks/dylibs, extensions, and the parent app consistently. An IPA re-signed with incorrect entitlements may install but fail to access the group.
- Test group availability in both processes before testing audio; avoid replacing your daily-driver Discord app during development.
