#include "AppGroup.h"
#include <QStandardPaths>
QString mfGroupDirectory(){return QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);}
