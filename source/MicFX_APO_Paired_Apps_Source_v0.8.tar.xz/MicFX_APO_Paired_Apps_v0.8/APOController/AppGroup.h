#pragma once
#include <QString>
// Absolute path of authorized App Group. Empty means signing/entitlement failure.
QString mfGroupDirectory();
