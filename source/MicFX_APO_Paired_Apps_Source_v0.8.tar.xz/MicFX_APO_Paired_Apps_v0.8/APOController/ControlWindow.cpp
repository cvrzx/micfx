#include "ControlWindow.h"
#include "AppGroup.h"
#include <QApplication>
#include <QStatusBar>
#include <QAction>
#include <QStringList>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QSaveFile>
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QDir>
#include <QDateTime>
#include <QSignalBlocker>
#include <QMessageBox>
#include <QDial>
#include <QMenuBar>
#include <cmath>

ControlWindow::ControlWindow(QWidget* parent):QMainWindow(parent){
 setWindowTitle("Equalizer APO — MicFX Control");
 resize(760,700);
 auto *tabs=new QTabWidget(this);
 setCentralWidget(tabs);
 // Both dial/number forms are genuine upstream APO .ui files processed by Qt uic.
 auto *micPage=new QWidget;
 auto *micLayout=new QVBoxLayout(micPage);
 micPreWidget=new QWidget;preamp.setupUi(micPreWidget);
 preamp.dial->setFixedSize(100,66);
 micLayout->addWidget(micPreWidget);
 biquadWidget=new QWidget;biquad.setupUi(biquadWidget);
 biquad.freqDial->setFixedSize(100,66);
 biquad.gainDial->setFixedSize(100,66);
 biquad.qDial->setFixedSize(100,66);
 biquad.typeComboBox->addItems({"Peaking filter","Low-pass filter","High-pass filter","Band-pass filter","Low-shelf filter","High-shelf filter","Notch filter","All-pass filter"});
 biquad.freqComboBox->addItem("Center frequency");
 biquad.qComboBox->addItem("Q factor");
 biquad.gainSpinBox->setValue(0);
 biquad.freqSpinBox->setValue(1000);
 biquad.qSpinBox->setValue(1);
 micLayout->addWidget(biquadWidget);
 micLayout->addStretch();
 tabs->addTab(micPage,"Equalizer APO · Mic");
 auto *extra=new QWidget;auto *extraLayout=new QVBoxLayout(extra);
 auto *row=new QHBoxLayout;row->addWidget(new QLabel("Microphone stereo routing:"));
 route=new QComboBox;route->addItems({"Both (L+R)","Left only","Right only"});row->addWidget(route);
 extraLayout->addLayout(row);
 micEnabled=new QCheckBox("Enable experimental Discord microphone processing (off by default)"); extraLayout->addWidget(micEnabled);
 micMute=new QCheckBox("Mute microphone, keep music playing"); extraLayout->addWidget(micMute);
 extraLayout->addWidget(new QLabel("Stereo routing is applied where the audio transport supports it. Discord may transmit mono."));
 extraLayout->addStretch();tabs->addTab(extra,"MicFX · Microphone");
 auto *musicPage=new QWidget;auto *musicLayout=new QVBoxLayout(musicPage);
 musicPreWidget=new QWidget;musicPreamp.setupUi(musicPreWidget);
 musicPreamp.dial->setFixedSize(100,66);
 musicLayout->addWidget(musicPreWidget);
 musicLayout->addWidget(new QLabel("Music gain applies only when a permitted stereo PCM sender is connected.\nThe stock Spotify app does not provide PCM via App Groups."));
 musicLayout->addStretch();tabs->addTab(musicPage,"MicFX · Stereo Music");
 auto* tools=menuBar()->addMenu("File");
 auto *saveAction=tools->addAction("Save settings to Discord");
 QObject::connect(saveAction,&QAction::triggered,this,[this]{save();});
 status=new QLabel; statusBar()->addWidget(status);
 connectPreamp(preamp);connectPreamp(musicPreamp);connectBiquad();
 QObject::connect(route,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this](int){save();});
 QObject::connect(micMute,&QCheckBox::toggled,this,[this](bool){save();});
 QObject::connect(micEnabled,&QCheckBox::toggled,this,[this](bool){save();});
 save();
}
void ControlWindow::connectPreamp(Ui::PreampFilterGUI& ui){
 QObject::connect(ui.dial,&QDial::valueChanged,this,[this,&ui](int v){ui.doubleSpinBox->setValue(v*.1);});
 QObject::connect(ui.doubleSpinBox,QOverload<double>::of(&QDoubleSpinBox::valueChanged),this,[this,&ui](double v){
  QSignalBlocker blocker(ui.dial);ui.dial->setValue(std::lround(v/.1));save();
 });
}
void ControlWindow::connectBiquad(){
 // Faithful to APO BiQuadFilterGUI.cpp logarithmic frequency/Q dial mapping.
 QObject::connect(biquad.freqDial,&QDial::valueChanged,this,[this](int v){
  biquad.freqSpinBox->setValue(20.*std::pow(1000.,v/1000.));
 });
 QObject::connect(biquad.freqSpinBox,QOverload<double>::of(&QDoubleSpinBox::valueChanged),this,[this](double v){
  if(v>0){QSignalBlocker b(biquad.freqDial);biquad.freqDial->setValue(std::lround(1000.*std::log(v/20.)/std::log(1000.)));}save();
 });
 QObject::connect(biquad.gainDial,&QDial::valueChanged,this,[this](int v){biquad.gainSpinBox->setValue(v*.1);});
 QObject::connect(biquad.gainSpinBox,QOverload<double>::of(&QDoubleSpinBox::valueChanged),this,[this](double v){QSignalBlocker b(biquad.gainDial);biquad.gainDial->setValue(std::lround(v/.1));save();});
 QObject::connect(biquad.qDial,&QDial::valueChanged,this,[this](int v){biquad.qSpinBox->setValue(.3333*std::pow(100.,v/1000.));});
 QObject::connect(biquad.qSpinBox,QOverload<double>::of(&QDoubleSpinBox::valueChanged),this,[this](double v){if(v>0){QSignalBlocker b(biquad.qDial);biquad.qDial->setValue(std::lround(1000.*std::log(v/.3333)/std::log(100.)));}save();});
 QObject::connect(biquad.typeComboBox,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this](int){save();});
}
void ControlWindow::save(){
 if(updating)return;
 QString dir=mfGroupDirectory();
 if(dir.isEmpty()) {if(status)status->setText("App Group unavailable: check provisioning/signature");return;}
 QDir().mkpath(dir);
 double gain=preamp.doubleSpinBox->value();
 double musicGain=musicPreamp.doubleSpinBox->value();
 double freq=biquad.freqSpinBox->value(),q=biquad.qSpinBox->value(),fg=biquad.gainSpinBox->value();
 const int t=biquad.typeComboBox->currentIndex();
 const QStringList types={"PK","LPQ","HPQ","BP","LS","HS","NO","AP"};
 const QString type=types.value(t,"PK");
 const double l=route->currentIndex()==2?0:1;
 const double r=route->currentIndex()==1?0:1;
 QJsonObject root{{"schema",1},
  {"mic",QJsonObject{{"enabled",micEnabled->isChecked()},{"gainDb",gain},{"mute",micMute->isChecked()},{"left",l},{"right",r}}},
  {"music",QJsonObject{{"gainDb",musicGain}}},
  {"eq",QJsonObject{{"filters",QJsonArray{QJsonObject{{"type",type},{"freqHz",freq},{"gainDb",fg},{"q",q}}}}}},
  {"configText",QString("Preamp: %1 dB\nFilter: ON %2 Fc %3 Hz Gain %4 dB Q %5\n").arg(gain).arg(type).arg(freq).arg(fg).arg(q)}};
 QSaveFile out(dir+"/micfx-control-v1.json");
 if(!out.open(QIODevice::WriteOnly)){if(status)status->setText("Cannot write App Group settings");return;}
 QByteArray data=QJsonDocument(root).toJson(QJsonDocument::Indented);
 if(out.write(data)!=data.size()||!out.commit()){if(status)status->setText("Settings save failed");return;}
 if(status)status->setText("Saved shared settings — native Discord hook integration required");
}
