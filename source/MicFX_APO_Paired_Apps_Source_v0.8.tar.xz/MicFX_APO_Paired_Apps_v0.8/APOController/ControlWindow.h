#pragma once
#include <QMainWindow>
#include <QJsonObject>
#include <QLabel>
#include <QComboBox>
#include <QCheckBox>
#include <QDoubleSpinBox>
#include "ui_PreampFilterGUI.h"
#include "ui_BiQuadFilterGUI.h"
class ControlWindow final: public QMainWindow {
public:
 explicit ControlWindow(QWidget* parent=nullptr);
private:
 Ui::PreampFilterGUI preamp, musicPreamp;
 Ui::BiQuadFilterGUI biquad;
 QComboBox* route=nullptr;
 QCheckBox* micMute=nullptr;
 QCheckBox* micEnabled=nullptr;
 QLabel* status=nullptr;
 QWidget* micPreWidget=nullptr;
 QWidget* musicPreWidget=nullptr;
 QWidget* biquadWidget=nullptr;
 bool updating=false;
 void save();
 void connectPreamp(Ui::PreampFilterGUI& ui);
 void connectBiquad();
};
