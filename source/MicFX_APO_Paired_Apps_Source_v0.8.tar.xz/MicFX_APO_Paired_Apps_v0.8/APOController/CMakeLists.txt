cmake_minimum_required(VERSION 3.24)
project(MicFX_APO_Control LANGUAGES CXX OBJCXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)
find_package(Qt6 6.5 REQUIRED COMPONENTS Core Widgets)
set(APO_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../original/EqualizerAPO-upstream" CACHE PATH "Original EqualizerAPO source checkout")
if(NOT EXISTS "${APO_ROOT}/Editor/guis/PreampFilterGUI.ui")
  message(FATAL_ERROR "Original APO .ui files missing. Run ../original/fetch-original-qt-source.sh first.")
endif()
qt_add_executable(MicFXAPOController MANUAL_FINALIZATION MACOSX_BUNDLE
  main.cpp ControlWindow.cpp ControlWindow.h AppGroup.h
  "${APO_ROOT}/Editor/guis/PreampFilterGUI.ui"
  "${APO_ROOT}/Editor/guis/BiQuadFilterGUI.ui"
  "${APO_ROOT}/Editor/guis/GraphicEQFilterGUI.ui"
  "${APO_ROOT}/Editor/guis/DelayFilterGUI.ui"
  "${APO_ROOT}/Editor/guis/ConvolutionFilterGUI.ui"
)
if(IOS)
  target_sources(MicFXAPOController PRIVATE AppGroup.mm)
  set_target_properties(MicFXAPOController PROPERTIES
    XCODE_ATTRIBUTE_CODE_SIGN_ENTITLEMENTS "${CMAKE_CURRENT_SOURCE_DIR}/../signing/APOController.entitlements"
    MACOSX_BUNDLE_GUI_IDENTIFIER "com.micfx.apo.control"
    MACOSX_BUNDLE_INFO_PLIST "${CMAKE_CURRENT_SOURCE_DIR}/Info.plist"
    XCODE_ATTRIBUTE_TARGETED_DEVICE_FAMILY "1,2"
    XCODE_ATTRIBUTE_IPHONEOS_DEPLOYMENT_TARGET "16.0"
  )
  target_link_libraries(MicFXAPOController PRIVATE "-framework Foundation")
else()
  target_sources(MicFXAPOController PRIVATE AppGroup.cpp)
endif()
target_include_directories(MicFXAPOController PRIVATE "${APO_ROOT}/Editor/guis")
target_link_libraries(MicFXAPOController PRIVATE Qt6::Core Qt6::Widgets)
qt_finalize_executable(MicFXAPOController)
