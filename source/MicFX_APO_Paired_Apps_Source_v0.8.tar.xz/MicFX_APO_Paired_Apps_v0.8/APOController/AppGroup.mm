#import <Foundation/Foundation.h>
#include "AppGroup.h"
#ifndef MF_APP_GROUP
#define MF_APP_GROUP "group.f172ad8c5e5f97bc.1"
#endif
QString mfGroupDirectory(){
 @autoreleasepool {
  NSURL *url=[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:
    [NSString stringWithUTF8String:MF_APP_GROUP]];
  if(!url) return QString();
  return QString::fromNSString(url.path);
 }
}
