# MicFX IPC Contract v1

Group: `group.f172ad8c5e5f97bc.1` ONLY if a valid provisioning profile for **each** app authorizes it.

A Qt control app writes `micfx-control-v1.json` using atomic replace in its App Group directory. Discord's native worker reads and validates it periodically (50 ms suggested), never from the render callback. A music sender may write `stereo-slot-XX.bin` 20 ms 48 kHz stereo packets; no producer for the *stock Spotify app* is provided.

Control file JSON:

```json
{
  "schema": 1,
  "mic": {"enabled": false, "gainDb": -6.0, "mute": false, "left": 1.0, "right": 1.0},
  "music": {"gainDb": -12.0},
  "eq": {"filters": [{"type": "PK", "freqHz": 1000, "gainDb": 0, "q": 1}]},
  "configText": "Preamp: -6 dB\nFilter: ON PK Fc 1000 Hz Gain 0 dB Q 1\n"
}
```

The current native settings reader applies only the documented microphone/music gain, mute, and left/right levels. The `eq`/`configText` fields are preserved for the next DSP integration stage; these are **not** applied by the current Discord hook. At runtime stereo EQ samples are supported by MicFXDSP.c when actual stereo PCM inputs are provided.

To control a Discord background call, Discord must stay active as a voice-audio process and its audio capture/render hook must execute. App Group updates do not keep a background process alive themselves. The target Discord capture path may be mono; stereo routing cannot force stereo Opus transmission.

The stock Spotify app cannot be given the group by editing MicFX alone. Audio output from Spotify must not be assumed accessible through this group, and this package does not bypass Spotify/DRM restrictions.
