#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Retrieve real Equalizer APO Qt Designer forms, Qt C++ editor source and resources.
# This fetches upstream source; it does not build an iOS app.
if [ -d EqualizerAPO-upstream ]; then
 echo 'EqualizerAPO-upstream already exists; leaving it unchanged.'
else
 git clone --depth 1 https://github.com/mirror/equalizerapo.git EqualizerAPO-upstream
fi
for f in MainWindow.ui FilterTableRow.ui guis/PreampFilterGUI.ui guis/BiQuadFilterGUI.ui guis/GraphicEQFilterGUI.ui; do
 test -s "EqualizerAPO-upstream/Editor/$f" || { echo "Missing $f"; exit 1; }
done
printf 'Original Qt UI source is in: %s\n' "$(pwd)/EqualizerAPO-upstream/Editor"
printf 'WARNING: upstream Editor.pro targets Windows libs; not directly buildable on iOS.\n'
