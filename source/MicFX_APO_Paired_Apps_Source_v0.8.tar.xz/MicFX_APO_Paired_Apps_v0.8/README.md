# MicFX + original Equalizer APO Qt iOS control app — v0.8 engineering source

**Status: integration source, NOT a finished pair of IPAs.** No feature is presented as installed or device-tested. The original user IPA is unmodified.

## What's real in this package

1. **Original Equalizer APO resources:** exact Configuration Editor executable and extracted power/toolbar icons from the user-supplied Equalizer APO 1.4.2 installer, plus GPL license. `original/fetch-original-qt-source.sh` retrieves original upstream Qt Designer forms/C++ sources on macOS. Its mirror revision may differ from 1.4.2; pin/verify against installer release before distribution.
2. **Qt control app:** `APOController` references the real `PreampFilterGUI.ui`, `BiQuadFilterGUI.ui`, `GraphicEQFilterGUI.ui`, `DelayFilterGUI.ui`, and `ConvolutionFilterGUI.ui` from the upstream checkout, and actually instantiates preamp and biquad forms through Qt `uic`. Original gain dials, numeric spin boxes, and the original logarithmic frequency/Q formulas are used in its working control form. **The entire original APO main window is not yet ported; do not call this a full APO GUI.** Extra MicFX microphone routing and music controls live on separate tabs. App writes settings atomically to its authorized App Group.
3. **Experimental Discord-native runtime:** `MicFXDSP.c` processes independent L/R PCM and mic/music gains; `StereoBridge.c` receives actual stereo packets when sent by an authorized source. `SharedControl.mm` reads the Qt app's settings every 50 ms on an IO worker, keeping file IO off the audio render thread. `DiscordAudioHook.mm` attempts AudioUnit hooking against one **specific UUID** from the uploaded fresh Endcord IPA. It starts OFF unless the control app enables it. The known capture format is **mono**; it downmixes to mono for Discord output. No guaranteed stereo voice-to-peer. Hooks depend on iOS allowing GOT page rebinding, and must be tested on device before installation as a daily driver.
4. **IPA injector:** `tools/patch_ipa.py` inserts the newly compiled **linked Mach-O dylib** and adds a load command to that exact Discord executable; rejects an object file, unknown UUID and inadequate header slack. Creates an **unsigned** IPA. You must authorize the App Group, sign both apps correctly, and test installation; it is not sufficient to put a profile in the ZIP.
5. **Original app group:** the submitted Endcord IPA contains a provisioning profile listing `group.f172ad8c5e5f97bc.1`; sharing this exact ID with the new app requires compatible signing entitlements and provisioning profiles for each bundle identifier. The old IPA's embedded `cyan.entitlements` is not proof that the group is authorized for the new application.

## Not yet completed

- Full Equalizer APO Qt Windows application port: original editor depends on Windows registry, COM and device/APO plumbing, VST DLLs and Windows-only libraries. Qt Widgets UI elements can be reused; the complete Windows application cannot be transplanted into iOS unchanged.
- Applying the Qt editor's EQ filter chain (`configText`, `eq.filters`) to the live Discord microphone; currently **only gain, L/R routing levels and mute** are applied through the settings bridge. The standalone DSP engine supports filters, but no validated live hot-swap yet.
- Direct Spotify PCM capture. Stock Spotify is neither signed into this custom App Group nor a PCM sender. A source must explicitly supply audio to `SharedMusicWriter.mm`. Never assert the stock Spotify app is bridged.
- Real MP3 recording in the installed Discord app. Prior MP3 tests used simulated PCM.
- Compiled `.dylib`, pair of signed IPA bundles, and on-device call/foreground/background stability tests. This workspace lacks Apple's iPhoneOS SDK and an iOS linker.

## Build on Mac

Requires Xcode/iOS SDK, Qt 6.5+ with Qt for iOS arm64 kit, a proper Apple Developer signing setup capable of authorizing App Groups for both bundle IDs, and network access to the original upstream repository.

```bash
./tools/run-tests.sh
export QT_IOS_PREFIX=/path/to/Qt/6.x/ios
./tools/build-on-mac.sh
```

After ensuring `dist/MicFXNative.dylib` is a valid signed-compatible ARM64 Mach-O dylib, use:

```bash
python3 tools/patch_ipa.py Endcord_344.1_1795214346.ipa dist/MicFXNative.dylib dist/Endcord-MicFX-UNSIGNED.ipa
```

**Re-sign the unsigned Discord IPA and Qt application with authorized, matching App Group entitlements.** On-device verify: hook installation, mic gain and mute, call continuing while Discord backgrounds, APO settings updates applied, recordings and stereo capabilities. Do not overwrite a working Discord app during testing without a backup.

## Testing in this environment

`tools/run-tests.sh` exercises portable C processing, stereo route/mute/music invariants, and verifies the Mach-O load command can be added to the user-provided Discord executable. Native iOS Objective-C++, Qt compilation, app signing, Spotify PCM, and end-to-end Discord voice calls cannot be tested here.

## License

Equalizer APO source and resources are GPL-2.0-or-later. Keep copyright/license notices and distribute corresponding source where required. This is an independent experimental project, not an official Equalizer APO or Discord release.
