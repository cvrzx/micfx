#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <stdatomic.h>
#include "../MicFXNative/MicFXDSP.h"
#include "../MicFXNative/SharedControl.h"
#include "../MicFXNative/StereoBridge.h"
static int near(float a,float b,float tol){return fabsf(a-b)<tol;}
int main(void){
 MFEngine dsp;
 mf_init(&dsp,48000);
 mf_control_reset();
 atomic_store(&mf_shared.micGainDb,0.0f);
 atomic_store(&mf_shared.musicGainDb,0.0f);
 atomic_store(&mf_shared.left,1.f);
 atomic_store(&mf_shared.right,0.f);
 mf_control_apply(&dsp);
 float mic[4]={.2f,-.2f,.3f,-.3f};
 float musL[4]={.1f,.1f,.1f,.1f};
 float musR[4]={-.1f,-.1f,-.1f,-.1f};
 float l[4],r[4];
 mf_process(&dsp,mic,mic,musL,musR,l,r,4);
 assert(near(l[0],tanhf(.3f),.0001f));
 assert(near(r[0],tanhf(-.1f),.0001f)); // mute right mic, keep right music
 atomic_store(&mf_shared.muted,1);
 mf_control_apply(&dsp);
 mf_process(&dsp,mic,mic,musL,musR,l,r,4);
 assert(near(l[0],tanhf(.1f),.0001f));
 assert(near(r[0],tanhf(-.1f),.0001f));
 MBStereoReceiver recv;mb_receiver_init(&recv);
 float pl[MB_STEREO_FRAMES],pr[MB_STEREO_FRAMES];
 for(unsigned i=0;i<MB_STEREO_FRAMES;i++){pl[i]=.3f;pr[i]=-.3f;}
 MBStereoPacket packet;mb_pack(&packet,pl,pr,100,1,1000);
 assert(mb_validate(&packet));
 assert(mb_receiver_feed(&recv,&packet,1001));
 float ol[16],orr[16];assert(mb_receiver_pop(&recv,ol,orr,16)==16);
 assert(ol[0]>0&&orr[0]<0);
 assert(mb_receiver_feed(&recv,&packet,1002)==0); // prevent replay
 puts("PASS: shared settings, mic mute with music continuing, L/R, stereo packets and replay defense");
 return 0;
}
