import sys,unittest,zipfile,struct,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from patch_ipa import read_cmds,patch_load_command,LOAD_NAME
BASE=pathlib.Path(__file__).resolve().parents[2]/'Endcord_344.1_1795214346.ipa'
class MachTests(unittest.TestCase):
 def test_verified_executable_and_injection(self):
  if not BASE.exists(): self.skipTest('Base IPA not mounted')
  with zipfile.ZipFile(BASE) as z:exe=z.read('Payload/Discord.app/Discord')
  new,changed=patch_load_command(exe)
  self.assertTrue(changed)
  old_type,old_n,old_size,_=read_cmds(exe)
  new_type,new_n,new_size,cmds=read_cmds(new)
  self.assertEqual((old_n+1),new_n)
  self.assertGreater(new_size,old_size)
  self.assertEqual(exe[new_size+32:],new[new_size+32:])
  twice,changed=patch_load_command(new)
  self.assertFalse(changed)
  self.assertEqual(twice,new)
 def test_uuid_mismatch_refused(self):
  if not BASE.exists(): self.skipTest('Base IPA not mounted')
  with zipfile.ZipFile(BASE) as z:exe=z.read('Payload/Discord.app/Discord')
  with self.assertRaisesRegex(ValueError,'UUID'):patch_load_command(exe,'00000000-0000-0000-0000-000000000001')
if __name__=='__main__': unittest.main()
