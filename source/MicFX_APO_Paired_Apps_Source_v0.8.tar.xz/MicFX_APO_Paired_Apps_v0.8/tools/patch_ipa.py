#!/usr/bin/env python3
"""Add a compiled iOS dylib dependency to the verified fresh Endcord IPA.

Output is UNSIGNED and must be re-signed with a compatible profile/entitlements.
This tool does not magically make a Discord audio hook functional.
"""
import argparse, pathlib, struct, uuid, zipfile, tempfile, os, shutil

TARGET_UUID = 'c7693551-f7aa-399a-9d24-41014f85f9b8'
MAGIC64 = 0xfeedfacf
LC_LOAD_DYLIB = 0xc
LC_UUID = 0x1b
LC_SEGMENT_64 = 0x19
MH_DYLIB = 6
MAIN = 'Payload/Discord.app/Discord'
DYLIB = 'Payload/Discord.app/Frameworks/MicFXNative.dylib'
LOAD_NAME = '@rpath/MicFXNative.dylib'


def read_cmds(data):
    if len(data) < 32 or struct.unpack_from('<I', data)[0] != MAGIC64:
        raise ValueError('Expected 64-bit little-endian ARM64 Mach-O')
    magic, cpu, subtype, ftype, ncmds, size, flags, reserved = struct.unpack_from('<8I', data)
    if cpu != 0x0100000c:
        raise ValueError('Not an ARM64 executable')
    pos=32; end=32+size; commands=[]
    if end>len(data): raise ValueError('Invalid command length')
    for _ in range(ncmds):
        if pos+8>end: raise ValueError('Truncated load commands')
        command, length = struct.unpack_from('<II',data,pos)
        if length<8 or pos+length>end or length%8: raise ValueError('Malformed load command')
        commands.append((pos,command,length))
        pos+=length
    if pos!=end: raise ValueError('Load command size mismatch')
    return ftype,ncmds,size,commands


def patch_load_command(data, expected_uuid=TARGET_UUID):
    data=bytearray(data)
    ftype,ncmds,old_size,cmds=read_cmds(data)
    if ftype != 2: raise ValueError('Main file is not a Mach-O executable')
    found_uuid=None
    first_section=len(data)
    existing=[]
    for pos, cmd, length in cmds:
        if cmd==LC_UUID and length>=24: found_uuid=str(uuid.UUID(bytes=bytes(data[pos+8:pos+24])))
        if cmd==LC_SEGMENT_64:
            nsects,=struct.unpack_from('<I',data,pos+64)
            for i in range(nsects):
                section=pos+72+i*80
                if section+80>pos+length: raise ValueError('Invalid section count')
                offset,=struct.unpack_from('<I',data,section+48)
                if offset:first_section=min(first_section,offset)
        if cmd in (0xc,0x18,0x1f,0x23,0x80000018,0x8000001c):
            off,=struct.unpack_from('<I',data,pos+8)
            if off<length:
                name=data[pos+off:pos+length].split(b'\0')[0].decode('utf-8','ignore')
                existing.append(name)
    if found_uuid != expected_uuid:
        raise ValueError(f'Base Discord UUID {found_uuid} differs from expected {expected_uuid}')
    if LOAD_NAME in existing: return bytes(data), False
    encoded=LOAD_NAME.encode()+b'\0'; cmdsize=(24+len(encoded)+7)&~7
    append_at=32+old_size
    if append_at+cmdsize>first_section:raise ValueError('No load-command header slack')
    if any(data[append_at:append_at+cmdsize]):
        raise ValueError('Header slack not empty; refusing unsafe overwrite')
    struct.pack_into('<6I',data,append_at,LC_LOAD_DYLIB,cmdsize,24,0,0x10000,0x10000)
    data[append_at+24:append_at+24+len(encoded)]=encoded
    struct.pack_into('<2I',data,16,ncmds+1,old_size+cmdsize)
    return bytes(data), True


def validate_dylib(data):
    filetype,_,_,_ = read_cmds(data)
    if filetype != MH_DYLIB: raise ValueError('Supplied dylib is not a linked Mach-O dynamic library')


def main():
    pa=argparse.ArgumentParser(description=__doc__)
    pa.add_argument('base_ipa',type=pathlib.Path)
    pa.add_argument('compiled_dylib',type=pathlib.Path)
    pa.add_argument('unsigned_output',type=pathlib.Path)
    a=pa.parse_args()
    if a.unsigned_output.resolve()==a.base_ipa.resolve(): raise ValueError('Refusing to overwrite base IPA')
    dylib=a.compiled_dylib.read_bytes()
    validate_dylib(dylib)
    a.unsigned_output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(a.base_ipa,'r') as src, zipfile.ZipFile(a.unsigned_output,'w') as out:
        names=set(src.namelist())
        if MAIN not in names:raise ValueError('Discord executable missing')
        if DYLIB in names:raise ValueError('IPA already contains MicFXNative.dylib')
        for info in src.infolist():
            content=src.read(info.filename)
            if info.filename==MAIN:
                content, modified=patch_load_command(content)
                if not modified:raise ValueError('Dylib already referenced by Discord executable')
            out.writestr(info,content)
        out.writestr(DYLIB,dylib,compress_type=zipfile.ZIP_DEFLATED)
    print('Created UNSIGNED IPA:',a.unsigned_output)
    print('IMPORTANT: Provide correct App Group entitlements and provisioning profile to a signer.')

if __name__=='__main__':main()
