#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
cc -std=c11 -O2 -Wall -Wextra -I MicFXNative tests/test_dsp_control.c \
  MicFXNative/MicFXDSP.c MicFXNative/StereoBridge.c MicFXNative/SharedControl.c \
  -lm -o dist/test_dsp_control
dist/test_dsp_control
python3 -m unittest discover -s tests -v
# Check portable C files cross-compile into arm64-apple-ios object code.
if command -v xcrun >/dev/null && xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
 for f in MicFXDSP StereoBridge SharedControl; do
  xcrun --sdk iphoneos clang -arch arm64 -miphoneos-version-min=16.0 -std=c11 -O2 -fPIC -c "MicFXNative/$f.c" -o "dist/$f-arm64-ios.o"
 done
 echo 'PASS: three ARM64 iOS C object compilations (NOT linked dylibs)'
else
 echo 'SKIP: iOS SDK cross-compile unavailable in this environment'
fi
