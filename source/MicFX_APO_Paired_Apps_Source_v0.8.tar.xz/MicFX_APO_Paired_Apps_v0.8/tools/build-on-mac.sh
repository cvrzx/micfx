#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo '=== Preparing original Equalizer APO sources ==='
original/fetch-original-qt-source.sh
echo '=== Building native Discord audio engine ==='
MicFXNative/build-ios.sh
echo '=== Generating Qt iOS project ==='
: "${QT_IOS_PREFIX:?Set QT_IOS_PREFIX to your Qt for iOS installation directory}"
cmake -S APOController -B dist/qt-ios -G Xcode \
 -DCMAKE_SYSTEM_NAME=iOS -DCMAKE_OSX_SYSROOT=iphoneos -DCMAKE_OSX_ARCHITECTURES=arm64 \
 -DCMAKE_PREFIX_PATH="$QT_IOS_PREFIX"
echo 'Now build and sign the Qt app in Xcode with a profile that authorizes the App Group.'
cmake --build dist/qt-ios --config Release
