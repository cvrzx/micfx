#include "MicFXDSP.h"
#include <math.h>
#include <string.h>
static float clampf(float x,float lo,float hi){if(!isfinite(x))return lo;return fminf(hi,fmaxf(lo,x));}
static float amp(float db){return powf(10.f,clampf(db,-90.f,24.f)/20.f);}
static int coeff(MFBiquad *b,const MFFilter *f,float sr){
 if(!b||!f||f->frequency<=0||f->frequency>=sr*.49f||f->q<=0)return -1;
 const float pi=3.14159265358979323846f;
 float w=2.f*pi*f->frequency/sr,c=cosf(w),s=sinf(w),a=s/(2.f*f->q),A=powf(10.f,clampf(f->gainDb,-36.f,36.f)/40.f);
 float b0,b1,b2,a0,a1,a2;
 switch(f->type){
 case MF_PK:b0=1+a*A;b1=-2*c;b2=1-a*A;a0=1+a/A;a1=-2*c;a2=1-a/A;break;
 case MF_LP:b0=(1-c)/2;b1=1-c;b2=(1-c)/2;a0=1+a;a1=-2*c;a2=1-a;break;
 case MF_HP:b0=(1+c)/2;b1=-(1+c);b2=(1+c)/2;a0=1+a;a1=-2*c;a2=1-a;break;
 case MF_NOTCH:b0=1;b1=-2*c;b2=1;a0=1+a;a1=-2*c;a2=1-a;break;
 case MF_BANDPASS:b0=a;b1=0;b2=-a;a0=1+a;a1=-2*c;a2=1-a;break;
 case MF_ALLPASS:b0=1-a;b1=-2*c;b2=1+a;a0=1+a;a1=-2*c;a2=1-a;break;
 case MF_LOWSHELF:{float t=2*sqrtf(A)*a;b0=A*((A+1)-(A-1)*c+t);b1=2*A*((A-1)-(A+1)*c);b2=A*((A+1)-(A-1)*c-t);a0=(A+1)+(A-1)*c+t;a1=-2*((A-1)+(A+1)*c);a2=(A+1)+(A-1)*c-t;break;}
 case MF_HIGHSHELF:{float t=2*sqrtf(A)*a;b0=A*((A+1)+(A-1)*c+t);b1=-2*A*((A-1)+(A+1)*c);b2=A*((A+1)+(A-1)*c-t);a0=(A+1)-(A-1)*c+t;a1=2*((A-1)-(A+1)*c);a2=(A+1)-(A-1)*c-t;break;}
 default:return -2;
 }
 if(!isfinite(a0)||fabsf(a0)<1e-12f)return -3;
 *b=(MFBiquad){b0/a0,b1/a0,b2/a0,a1/a0,a2/a0,0,0};return 0;
}
void mf_init(MFEngine *e,float sr){memset(e,0,sizeof(*e));e->sampleRate=clampf(sr,8000,192000);e->micGain=e->musicGain=e->micLeft=e->micRight=1.f;e->enableLimiter=1;e->limiterDrive=1.f;}
int mf_set_filters(MFEngine *e,int music,const MFFilter *filters,unsigned n){
 if(!e||n>MF_MAX_FILTERS||(!filters&&n))return -1;
 MFBiquad tmp[2][MF_MAX_FILTERS]={0};int masks[MF_MAX_FILTERS]={0};
 for(unsigned i=0;i<n;i++){
  int mask=filters[i].mask&MF_ALL;
  if(!mask)return -2;
  for(int ch=0;ch<2;ch++)if(coeff(&tmp[ch][i],&filters[i],e->sampleRate))return -3;
  masks[i]=mask;
 }
 MFBiquad (*dst)[MF_MAX_FILTERS]=music?e->musicFilters:e->micFilters;
 int *maskDst=music?e->musicMask:e->micMask;
 memcpy(dst,tmp,sizeof(tmp));memcpy(maskDst,masks,sizeof(masks));
 if(music)e->musicCount=n;else e->micCount=n;return 0;
}
void mf_set_levels(MFEngine *e,float micDb,float musicDb,float left,float right,int mute,int limit){
 e->micGain=amp(micDb);e->musicGain=amp(musicDb);
 e->micLeft=clampf(left,0,2);e->micRight=clampf(right,0,2);
 e->muteMic=!!mute;e->enableLimiter=!!limit;
}
static float stage(MFBiquad *b,float x){float y=b->b0*x+b->z1;b->z1=b->b1*x-b->a1*y+b->z2;b->z2=b->b2*x-b->a2*y;return y;}
void mf_process(MFEngine *e,const float *micL,const float *micR,const float *musicL,const float *musicR,float *outL,float *outR,unsigned n){
 if(!e||!outL||!outR)return;
 // Call with stable config; never mutate filter configuration concurrently with render.
 for(unsigned i=0;i<n;i++){
  float m[2]={micL?micL[i]:0.f,micR?micR[i]:(micL?micL[i]:0.f)};
  float z[2]={musicL?musicL[i]:0.f,musicR?musicR[i]:0.f};
  for(int ch=0;ch<2;ch++){
   for(unsigned j=0;j<e->micCount;j++)if(e->micMask[j]&(1<<ch))m[ch]=stage(&e->micFilters[ch][j],m[ch]);
   for(unsigned j=0;j<e->musicCount;j++)if(e->musicMask[j]&(1<<ch))z[ch]=stage(&e->musicFilters[ch][j],z[ch]);
  }
  float left=z[0]*e->musicGain+(e->muteMic?0:m[0]*e->micGain*e->micLeft);
  float right=z[1]*e->musicGain+(e->muteMic?0:m[1]*e->micGain*e->micRight);
  if(e->enableLimiter){left=tanhf(left);right=tanhf(right);}
  outL[i]=isfinite(left)?left:0;outR[i]=isfinite(right)?right:0;
 }
}
