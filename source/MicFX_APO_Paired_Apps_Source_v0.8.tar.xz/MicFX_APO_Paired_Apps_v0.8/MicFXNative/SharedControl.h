#ifndef MF_SHARED_CONTROL_H
#define MF_SHARED_CONTROL_H
#include <stdatomic.h>
#include "MicFXDSP.h"
#ifdef __cplusplus
extern "C" {
#endif
// One writer (background IO), any number of audio render readers. All fields atomic.
typedef struct {
 _Atomic(float) micGainDb, musicGainDb, left, right;
 _Atomic(int) enabled, muted;
 _Atomic(unsigned) updates, errors;
} MFSharedControl;
extern MFSharedControl mf_shared;
void mf_control_reset(void);
void mf_control_apply(MFEngine *engine); // Must be called on the render thread that owns engine.
// Implemented in iOS/SharedControl.mm; Foundation IO MUST happen on a worker.
int mf_control_reload_from_app_group(void);
void mf_control_start_polling(void);
#ifdef __cplusplus
}
#endif
#endif
