// For an AUTHORIZED stereo PCM provider running under the same App Group.
// This is not a Spotify tap. Call only on an IO worker, not an audio render callback.
#import <Foundation/Foundation.h>
#import "StereoBridge.h"
#ifndef MF_APP_GROUP
#define MF_APP_GROUP "group.f172ad8c5e5f97bc.1"
#endif
int mf_publish_stereo_packet(const float *left,const float *right,uint64_t session,uint64_t sequence,uint64_t timestampMs){
 if(!left||!right||!session||!sequence)return -1;
 @autoreleasepool {
  NSURL *root=[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:
    [NSString stringWithUTF8String:MF_APP_GROUP]];
  if(!root)return -2;
  MBStereoPacket packet;mb_pack(&packet,left,right,session,sequence,timestampMs);
  NSString *name=[NSString stringWithFormat:@"stereo-slot-%02llu.bin",(unsigned long long)(sequence%16)];
  NSData *data=[NSData dataWithBytes:&packet length:sizeof(packet)];
  NSError *error=nil;
  if(![data writeToURL:[root URLByAppendingPathComponent:name] options:NSDataWritingAtomic error:&error])return -3;
  return 0;
 }
}
