// App Group configuration receiver for a MicFX runtime INSIDE Discord.
// Objective-C++ Foundation worker only; no file IO on the audio callback.
#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>
#import "SharedControl.h"
#include <unistd.h>
#include <math.h>
#ifndef MF_APP_GROUP
#define MF_APP_GROUP "group.f172ad8c5e5f97bc.1"
#endif
static NSString *groupName(void) { return [NSString stringWithUTF8String:MF_APP_GROUP]; }
static BOOL validNum(id value, double lo, double hi, float *out) {
 if (![value isKindOfClass:[NSNumber class]]) return NO;
 double x=[(NSNumber*)value doubleValue];
 if (!isfinite(x) || x<lo || x>hi) return NO;
 *out=(float)x; return YES;
}
int mf_control_reload_from_app_group(void) {
 @autoreleasepool {
  NSURL *root=[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:groupName()];
  if(!root){atomic_fetch_add(&mf_shared.errors,1);return -1;}
  NSURL *file=[root URLByAppendingPathComponent:@"micfx-control-v1.json"];
  NSData *bytes=[NSData dataWithContentsOfURL:file options:0 error:nil];
  if(!bytes || bytes.length>65536){atomic_fetch_add(&mf_shared.errors,1);return -2;}
  NSDictionary *data=[NSJSONSerialization JSONObjectWithData:bytes options:0 error:nil];
  if (![data isKindOfClass:[NSDictionary class]] || ![data[@"schema"] isEqual:@1]) {
   atomic_fetch_add(&mf_shared.errors,1);return -3;
  }
  NSDictionary *mic=data[@"mic"], *music=data[@"music"];
  if(![mic isKindOfClass:NSDictionary.class]||![music isKindOfClass:NSDictionary.class]) {
   atomic_fetch_add(&mf_shared.errors,1);return -4;
  }
  float mg,zg,l,r;
  if(!validNum(mic[@"gainDb"],-90,24,&mg) || !validNum(music[@"gainDb"],-90,24,&zg) ||
     !validNum(mic[@"left"],0,2,&l) || !validNum(mic[@"right"],0,2,&r) ||
     ![mic[@"mute"] isKindOfClass:NSNumber.class]){
    atomic_fetch_add(&mf_shared.errors,1);return -5;
  }
  // Off by default if an older config lacks the explicit enable flag.
  BOOL enabled=[mic[@"enabled"] isKindOfClass:NSNumber.class] && [mic[@"enabled"] boolValue];
  atomic_store(&mf_shared.enabled,enabled);
  atomic_store(&mf_shared.micGainDb,mg);
  atomic_store(&mf_shared.musicGainDb,zg);
  atomic_store(&mf_shared.left,l);
  atomic_store(&mf_shared.right,r);
  atomic_store(&mf_shared.muted,[mic[@"mute"] boolValue]);
  atomic_fetch_add(&mf_shared.updates,1);
  return 0;
 }
}
void mf_control_start_polling(void) {
 static dispatch_once_t once;
 dispatch_once(&once, ^{
  dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
   @autoreleasepool { mf_control_reset(); }
   for(;;){ mf_control_reload_from_app_group(); usleep(50000); }
  });
 });
}
