#ifndef MICFX_STEREO_BRIDGE_H
#define MICFX_STEREO_BRIDGE_H
#include <stdint.h>
#include <stdatomic.h>
#define MB_EXPORT __attribute__((visibility("default")))
#define MB_STEREO_RATE 48000
#define MB_STEREO_FRAMES 960
#define MB_STEREO_MAGIC 0x3258464du
#define MB_RING_FRAMES 16384u
// 20 ms stereo audio transport envelope; only valid when supplied with actual PCM.
typedef struct {
 uint32_t magic,frames,rate,channels;
 uint64_t session,sequence,timestampMs;
 uint32_t checksum,reserved;
 int16_t interleaved[MB_STEREO_FRAMES*2];
} MBStereoPacket;
typedef struct {
 _Atomic(uint32_t) writeIndex,readIndex,received,missed,rejected;
 float ring[MB_RING_FRAMES][2];
 uint64_t session,lastSequence;
} MBStereoReceiver;
MB_EXPORT void mb_receiver_init(MBStereoReceiver *r);
MB_EXPORT void mb_pack(MBStereoPacket *p,const float *left,const float *right,uint64_t session,uint64_t seq,uint64_t timestampMs);
MB_EXPORT int mb_validate(const MBStereoPacket *p);
// Call feed on one IO worker thread, never from the real-time render callback.
MB_EXPORT int mb_receiver_feed(MBStereoReceiver *r,const MBStereoPacket *p,uint64_t nowMs);
// Call from audio render thread, never performs file IO or allocates memory.
MB_EXPORT unsigned mb_receiver_pop(MBStereoReceiver *r,float *left,float *right,unsigned n);
#endif
