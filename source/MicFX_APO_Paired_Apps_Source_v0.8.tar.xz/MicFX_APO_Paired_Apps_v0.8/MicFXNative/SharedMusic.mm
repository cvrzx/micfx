// One possible App Group stereo packet receiver. The sender MUST provide actual
// PCM legally and at 48 kHz; this does not capture the stock Spotify app.
#import <Foundation/Foundation.h>
#import "StereoBridge.h"
#ifndef MF_APP_GROUP
#define MF_APP_GROUP "group.f172ad8c5e5f97bc.1"
#endif
int mf_music_receive_latest(MBStereoReceiver *receiver, uint64_t nowMs) {
 if (!receiver) return 0;
 @autoreleasepool {
  NSURL *root=[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:
    [NSString stringWithUTF8String:MF_APP_GROUP]];
  if (!root) return 0;
  int accepted=0;
  NSMutableArray<NSData *> *packets=[NSMutableArray array];
  for(unsigned slot=0;slot<16;slot++){
   NSString *name=[NSString stringWithFormat:@"stereo-slot-%02u.bin",slot];
   NSData *bytes=[NSData dataWithContentsOfURL:[root URLByAppendingPathComponent:name]];
   if(bytes.length!=sizeof(MBStereoPacket)) continue;
   MBStereoPacket packet; [bytes getBytes:&packet length:sizeof(packet)];
   if(mb_validate(&packet) && packet.timestampMs<=nowMs && nowMs-packet.timestampMs<=350) [packets addObject:bytes];
  }
  [packets sortUsingComparator:^NSComparisonResult(NSData *a,NSData *b){
    MBStereoPacket pa,pb;[a getBytes:&pa length:sizeof(pa)];[b getBytes:&pb length:sizeof(pb)];
    if(pa.session!=pb.session) return pa.timestampMs<pb.timestampMs?NSOrderedAscending:NSOrderedDescending;
    if(pa.sequence==pb.sequence) return NSOrderedSame;
    return pa.sequence<pb.sequence?NSOrderedAscending:NSOrderedDescending;
  }];
  for(NSData *b in packets){MBStereoPacket p;[b getBytes:&p length:sizeof(p)];if(mb_receiver_feed(receiver,&p,nowMs))accepted++;}
  return accepted;
 }
}
