#include "SharedControl.h"
#include <math.h>
MFSharedControl mf_shared={0};
void mf_control_reset(void) {
 atomic_store(&mf_shared.micGainDb,0);
 atomic_store(&mf_shared.musicGainDb,0);
 atomic_store(&mf_shared.left,1);
 atomic_store(&mf_shared.right,1);
 atomic_store(&mf_shared.enabled,0);
 atomic_store(&mf_shared.muted,0);
 atomic_store(&mf_shared.updates,0);
 atomic_store(&mf_shared.errors,0);
}
void mf_control_apply(MFEngine *e) {
 if(!e) return;
 float md=atomic_load(&mf_shared.micGainDb);
 float zd=atomic_load(&mf_shared.musicGainDb);
 float l=atomic_load(&mf_shared.left),r=atomic_load(&mf_shared.right);
 int mute=atomic_load(&mf_shared.muted);
 if(!isfinite(md)||!isfinite(zd)||!isfinite(l)||!isfinite(r)) return;
 mf_set_levels(e,md,zd,l,r,mute,1);
}
