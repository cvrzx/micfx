#ifndef MICFX_DSP_H
#define MICFX_DSP_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define MF_MAX_FILTERS 32
#define MF_API __attribute__((visibility("default")))
#define MF_ALL 3
#define MF_LEFT 1
#define MF_RIGHT 2
// Stable C ABI: all samples normalized float PCM; in-place permitted for outputs.
typedef enum {MF_PK=1,MF_LP,MF_HP,MF_NOTCH,MF_LOWSHELF,MF_HIGHSHELF,MF_BANDPASS,MF_ALLPASS} MFType;
typedef struct {float b0,b1,b2,a1,a2,z1,z2;} MFBiquad;
typedef struct {int type;int mask;float frequency,q,gainDb;} MFFilter;
typedef struct {
  float sampleRate, micGain, musicGain, micLeft, micRight, limiterDrive;
  int muteMic, enableLimiter;
  unsigned micCount,musicCount;
  MFBiquad micFilters[2][MF_MAX_FILTERS],musicFilters[2][MF_MAX_FILTERS];
  int micMask[MF_MAX_FILTERS],musicMask[MF_MAX_FILTERS];
} MFEngine;
MF_API void mf_init(MFEngine *e,float sampleRate);
MF_API int mf_set_filters(MFEngine *e,int isMusic,const MFFilter *filters,unsigned n);
MF_API void mf_set_levels(MFEngine *e,float micDb,float musicDb,float micLeft,float micRight,int mute,int limit);
MF_API void mf_process(MFEngine *e,const float *micL,const float *micR,const float *musicL,const float *musicR,float *outL,float *outR,unsigned frames);
#ifdef __cplusplus
}
#endif
#endif
