// Version-locked, disabled-by-default experimental Discord AudioUnit mic hook.
// It processes actual AudioUnit mono microphone frames; Discord's outgoing
// Opus pipeline may remain MONO. The native hook has not been tested on iPhone.
#import <AudioToolbox/AudioToolbox.h>
#import <Foundation/Foundation.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <dlfcn.h>
#include <unistd.h>
#include <stdatomic.h>
#include <pthread.h>
#include <string.h>
#include "SharedControl.h"
#include "StereoBridge.h"

static const uint8_t EXPECTED_UUID[16]={0xc7,0x69,0x35,0x51,0xf7,0xaa,0x39,0x9a,0x9d,0x24,0x41,0x01,0x4f,0x85,0xf9,0xb8};
static OSStatus (*oldInit)(AudioUnit);
static OSStatus (*oldRender)(AudioUnit,AudioUnitRenderActionFlags*,const AudioTimeStamp*,UInt32,UInt32,AudioBufferList*);
static OSStatus (*oldUninit)(AudioUnit);
static OSStatus (*oldDispose)(AudioComponentInstance);
static _Atomic(uintptr_t) micUnit;
static _Atomic(unsigned) rate,format; // 1: PCM S16 signed; 2: Float32
static atomic_flag audioBusy=ATOMIC_FLAG_INIT;
static MFEngine micEngine;
static MBStereoReceiver musicReceiver;
static _Atomic(unsigned) processedCount;
static const char *status="Hook not initialized";
extern int mf_music_receive_latest(MBStereoReceiver *,uint64_t);
static void forgetMic(AudioUnit unit){uintptr_t p=(uintptr_t)unit;atomic_compare_exchange_strong(&micUnit,&p,0);}
static OSStatus initHook(AudioUnit unit){
 OSStatus result=oldInit(unit);
 if(result)return result;
 AudioComponentDescription d={0};
 AudioComponent c=AudioComponentInstanceGetComponent(unit);
 if(!c||AudioComponentGetDescription(c,&d)||d.componentType!=kAudioUnitType_Output ||
    (d.componentSubType!=kAudioUnitSubType_RemoteIO && d.componentSubType!=kAudioUnitSubType_VoiceProcessingIO))return result;
 AudioStreamBasicDescription asbd={0};UInt32 len=sizeof(asbd);
 if(AudioUnitGetProperty(unit,kAudioUnitProperty_StreamFormat,kAudioUnitScope_Output,1,&asbd,&len)!=noErr || len!=sizeof(asbd))return result;
 if(asbd.mFormatID!=kAudioFormatLinearPCM || asbd.mChannelsPerFrame!=1 || asbd.mFramesPerPacket!=1 ||
    asbd.mSampleRate<8000 || asbd.mSampleRate>96000 || !(asbd.mFormatFlags&kAudioFormatFlagIsPacked))return result;
 unsigned kind=0;
 if(asbd.mBitsPerChannel==16 && asbd.mBytesPerFrame==2 && (asbd.mFormatFlags&kAudioFormatFlagIsSignedInteger))kind=1;
 if(asbd.mBitsPerChannel==32 && asbd.mBytesPerFrame==4 && (asbd.mFormatFlags&kAudioFormatFlagIsFloat))kind=2;
 if(!kind)return result;
 atomic_store(&micUnit,(uintptr_t)unit);atomic_store(&rate,(unsigned)asbd.mSampleRate);atomic_store(&format,kind);
 mf_init(&micEngine,(float)asbd.mSampleRate);
 return result;
}
static OSStatus uninitHook(AudioUnit unit){forgetMic(unit);return oldUninit(unit);}
static OSStatus disposeHook(AudioComponentInstance unit){forgetMic(unit);return oldDispose(unit);}
static OSStatus renderHook(AudioUnit unit,AudioUnitRenderActionFlags *flags,const AudioTimeStamp *stamp,UInt32 bus,UInt32 frames,AudioBufferList *buffer){
 OSStatus result=oldRender(unit,flags,stamp,bus,frames,buffer);
 if(result||!atomic_load(&mf_shared.enabled)||bus!=1||!frames||frames>2048||!buffer||buffer->mNumberBuffers!=1 ||
    atomic_load(&micUnit)!=(uintptr_t)unit)return result;
 unsigned fmt=atomic_load(&format),sr=atomic_load(&rate);
 if((fmt!=1&&fmt!=2)||!sr||buffer->mBuffers[0].mNumberChannels!=1 ||
    buffer->mBuffers[0].mDataByteSize<frames*(fmt==1?2u:4u)||!buffer->mBuffers[0].mData)return result;
 if(atomic_flag_test_and_set(&audioBusy))return result;
 // No IO, allocation, mutex, or dynamic hooks in render path.
 float in[2048],musicL[2048]={0},musicR[2048]={0},outL[2048],outR[2048];
 void *raw=buffer->mBuffers[0].mData;
 for(UInt32 i=0;i<frames;i++)in[i]=(fmt==1)?((int16_t*)raw)[i]/32768.f:((float*)raw)[i];
 // The current bridge is specifically 48 kHz; do not play at the wrong rate.
 if(sr==48000)mb_receiver_pop(&musicReceiver,musicL,musicR,frames);
 mf_control_apply(&micEngine);
 mf_process(&micEngine,in,in,musicL,musicR,outL,outR,frames);
 // The verified captured input is MONO, so center-downmix to preserve amplitude.
 for(UInt32 i=0;i<frames;i++){
  float y=(outL[i]+outR[i])*.5f;
  if(y>1.f)y=1.f;else if(y< -1.f)y=-1.f;
  if(fmt==1)((int16_t*)raw)[i]=(int16_t)(y*32767.f);else ((float*)raw)[i]=y;
 }
 atomic_fetch_add(&processedCount,1);
 atomic_flag_clear(&audioBusy);
 return result;
}
static int knownMainExecutable(void){
 const mach_header_64 *h=(const mach_header_64 *)_dyld_get_image_header(0);
 if(!h||h->magic!=MH_MAGIC_64||h->cputype!=CPU_TYPE_ARM64||h->sizeofcmds>65536)return 0;
 const uint8_t* p=(const uint8_t *)(h+1);
 for(uint32_t i=0;i<h->ncmds;i++){
  const load_command *cmd=(const load_command*)p;
  if(cmd->cmdsize<sizeof(load_command))return 0;
  if(cmd->cmd==LC_UUID){const uuid_command *uc=(const uuid_command *)p;return !memcmp(uc->uuid,EXPECTED_UUID,16);}
  p+=cmd->cmdsize;
 }return 0;
}
static int installHook(void){
 if(!knownMainExecutable()){status="Unknown Discord executable; hook disabled";return 0;}
 intptr_t slide=_dyld_get_image_vmaddr_slide(0);
 // Verified offsets are specific to Discord 344.1 UUID above.
 void **slot[]={(void**)(slide+0x102ccdad0ull),(void**)(slide+0x102ccdad8ull),
                (void**)(slide+0x102ccdae8ull),(void**)(slide+0x102ccda88ull)};
 void *original[]={dlsym(RTLD_DEFAULT,"AudioUnitInitialize"),dlsym(RTLD_DEFAULT,"AudioUnitRender"),
                   dlsym(RTLD_DEFAULT,"AudioUnitUninitialize"),dlsym(RTLD_DEFAULT,"AudioComponentInstanceDispose")};
 void *replacement[]={(void*)initHook,(void*)renderHook,(void*)uninitHook,(void*)disposeHook};
 for(int i=0;i<4;i++)if(!original[i]||*slot[i]!=original[i]){status="Unexpected import pointers; hook disabled";return 0;}
 oldInit=(decltype(oldInit))original[0];oldRender=(decltype(oldRender))original[1];
 oldUninit=(decltype(oldUninit))original[2];oldDispose=(decltype(oldDispose))original[3];
 const vm_size_t size=(vm_size_t)getpagesize();
 const mach_vm_address_t page=((mach_vm_address_t)slot[0])&~(size-1);
 for(int i=1;i<4;i++)if((((mach_vm_address_t)slot[i])&~(size-1))!=page){status="Import slots span pages; hook disabled";return 0;}
 if(mach_vm_protect(mach_task_self(),page,size,FALSE,VM_PROT_READ|VM_PROT_WRITE|VM_PROT_COPY)!=KERN_SUCCESS){status="Page protection denied; hook disabled";return 0;}
 for(int i=0;i<4;i++)__atomic_store_n(slot[i],replacement[i],__ATOMIC_RELEASE);
 if(mach_vm_protect(mach_task_self(),page,size,FALSE,VM_PROT_READ)!=KERN_SUCCESS){
  for(int i=0;i<4;i++)__atomic_store_n(slot[i],original[i],__ATOMIC_RELEASE);
  status="Page-protection restore failed; hook rolled back";return 0;
 }
 status="Installed: waiting for AudioUnit mic";return 1;
}
static void startMusicReader(void){
 dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
  for(;;){
   uint64_t now=(uint64_t)(NSDate.date.timeIntervalSince1970*1000);
   mf_music_receive_latest(&musicReceiver,now);
   usleep(20000);
  }
 });
}
__attribute__((visibility("default"))) const char *mf_runtime_status(void){return status;}
__attribute__((visibility("default"))) unsigned mf_runtime_frames_processed(void){return atomic_load(&processedCount);}
__attribute__((constructor)) static void startMicFX(void){
 mf_control_reset();mb_receiver_init(&musicReceiver);
 if(installHook()){
  mf_control_start_polling();
  startMusicReader();
 }
}
