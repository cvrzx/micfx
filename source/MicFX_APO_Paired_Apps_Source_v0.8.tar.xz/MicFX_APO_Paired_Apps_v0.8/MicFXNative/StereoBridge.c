#include "StereoBridge.h"
#include <string.h>
#include <math.h>
static uint32_t checksum(const int16_t *samples){uint32_t v=2166136261u;for(unsigned i=0;i<MB_STEREO_FRAMES*2;i++){uint16_t s=(uint16_t)samples[i];v=(v^(s&255))*16777619u;v=(v^(s>>8))*16777619u;}return v;}
static int16_t clamp16(float x){if(!isfinite(x))return 0;if(x>1.f)x=1.f;if(x< -1.f)x=-1.f;return (int16_t)lrintf(x*32767.f);}
void mb_receiver_init(MBStereoReceiver *r){memset(r,0,sizeof(*r));}
void mb_pack(MBStereoPacket *p,const float *l,const float *r,uint64_t session,uint64_t seq,uint64_t time){memset(p,0,sizeof(*p));p->magic=MB_STEREO_MAGIC;p->frames=MB_STEREO_FRAMES;p->rate=MB_STEREO_RATE;p->channels=2;p->session=session;p->sequence=seq;p->timestampMs=time;for(unsigned i=0;i<MB_STEREO_FRAMES;i++){p->interleaved[2*i]=clamp16(l?l[i]:0);p->interleaved[2*i+1]=clamp16(r?r[i]:0);}p->checksum=checksum(p->interleaved);}
int mb_validate(const MBStereoPacket *p){return p&&p->magic==MB_STEREO_MAGIC&&p->frames==MB_STEREO_FRAMES&&p->rate==MB_STEREO_RATE&&p->channels==2&&p->session&&p->sequence&&p->checksum==checksum(p->interleaved);}
int mb_receiver_feed(MBStereoReceiver *r,const MBStereoPacket *p,uint64_t now){
 if(!r||!mb_validate(p)||p->timestampMs>now||now-p->timestampMs>350){if(r)atomic_fetch_add(&r->rejected,1);return 0;}
 if(r->session!=p->session){r->session=p->session;r->lastSequence=0;atomic_store(&r->readIndex,0);atomic_store(&r->writeIndex,0);}
 if(p->sequence<=r->lastSequence){atomic_fetch_add(&r->rejected,1);return 0;}
 if(r->lastSequence&&p->sequence>r->lastSequence+1)atomic_fetch_add(&r->missed,1);
 r->lastSequence=p->sequence;
 uint32_t w=atomic_load_explicit(&r->writeIndex,memory_order_relaxed),q=atomic_load_explicit(&r->readIndex,memory_order_acquire);
 // Drop oldest buffered packet if full, without blocking. Reader is allowed to use newer frames.
 if(w-q>MB_RING_FRAMES-MB_STEREO_FRAMES-1){atomic_fetch_add(&r->rejected,1);return 0;}
 for(unsigned i=0;i<MB_STEREO_FRAMES;i++){uint32_t idx=(w+i)&(MB_RING_FRAMES-1);r->ring[idx][0]=(float)p->interleaved[i*2]/32768.f;r->ring[idx][1]=(float)p->interleaved[i*2+1]/32768.f;}
 atomic_store_explicit(&r->writeIndex,w+MB_STEREO_FRAMES,memory_order_release);
 atomic_fetch_add(&r->received,1);return 1;
}
unsigned mb_receiver_pop(MBStereoReceiver *r,float *l,float *rr,unsigned n){
 if(!r||!l||!rr)return 0;
 uint32_t q=atomic_load_explicit(&r->readIndex,memory_order_relaxed),w=atomic_load_explicit(&r->writeIndex,memory_order_acquire);unsigned available=w-q;unsigned take=n<available?n:available;for(unsigned i=0;i<take;i++){uint32_t idx=(q+i)&(MB_RING_FRAMES-1);l[i]=r->ring[idx][0];rr[i]=r->ring[idx][1];}for(unsigned i=take;i<n;i++){l[i]=0;rr[i]=0;}atomic_store_explicit(&r->readIndex,q+take,memory_order_release);return take;
}
