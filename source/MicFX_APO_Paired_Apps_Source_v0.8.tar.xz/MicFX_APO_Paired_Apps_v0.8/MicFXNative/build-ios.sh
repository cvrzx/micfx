#!/bin/bash
# Run on macOS with Xcode + iPhoneOS SDK. This builds DSP and IPC runtime,
# includes an EXPERIMENTAL, version-locked Discord AudioUnit hook (disabled by default).
set -euo pipefail
cd "$(dirname "$0")"
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
mkdir -p ../dist
mkdir -p ../dist/obj
for unit in MicFXDSP StereoBridge SharedControl; do
 xcrun --sdk iphoneos clang -arch arm64 -isysroot "$SDK" -miphoneos-version-min=16.0 -std=c11 -O2 -fPIC -c "$unit.c" -o "../dist/obj/$unit.o"
done
for unit in SharedControl SharedMusic SharedMusicWriter DiscordAudioHook; do
 xcrun --sdk iphoneos clang++ -arch arm64 -isysroot "$SDK" -miphoneos-version-min=16.0 -std=c++17 -fobjc-arc -fblocks -O2 -fPIC -c "$unit.mm" -o "../dist/obj/$unit-mm.o"
done
xcrun --sdk iphoneos clang++ -arch arm64 -isysroot "$SDK" -miphoneos-version-min=16.0 -dynamiclib -Wl,-install_name,@rpath/MicFXNative.dylib \
 ../dist/obj/*.o -framework Foundation -o ../dist/MicFXNative.dylib
file ../dist/MicFXNative.dylib
# Do not deploy to your everyday Discord until it passes device voice-call tests.
